from django.apps import AppConfig


class AfijoConfig(AppConfig):
    name = 'afijo'
